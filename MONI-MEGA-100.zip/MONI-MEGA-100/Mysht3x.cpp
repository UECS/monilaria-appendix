#include "MySHT3x.h"

SHT3x::SHT3x() {
}

bool SHT3x::begin(unsigned char i2caddr) {
  Wire.begin();
  _i2caddr = i2caddr;
  reset();
  return true;
}

void SHT3x::startMeasure(void)
{
writeCommand(0x2400);//MEAS_HIGHREP
return;
}


bool SHT3x::getTempHumid(void) {

  unsigned char i2cbuffer[6];
 
  Wire.requestFrom(_i2caddr, (unsigned char)6);
  if (Wire.available() != 6) 
    return false;
  for (unsigned char i=0; i<6; i++) {
    i2cbuffer[i] = Wire.read();
  }
  unsigned short SensorT, SensorRH;
  SensorT = i2cbuffer[0];
  SensorT <<= 8;
  SensorT |= i2cbuffer[1];

  if (i2cbuffer[2] != crc8Dallas(i2cbuffer, 2)) return false;

  SensorRH = i2cbuffer[3];
  SensorRH <<= 8;
  SensorRH |= i2cbuffer[4];

  if (i2cbuffer[5] != crc8Dallas(i2cbuffer+3, 2)) return false;

  temp = (double)SensorT*175.0/65535.0-45.0;
  humidity=(double)SensorRH*100.0/65535.0;

  return true;
}

void SHT3x::reset(void) {
  writeCommand(0x30A2);//reset command
  delay(10);
}

unsigned char SHT3x::crc8Dallas(const unsigned char *data, int len) {
  unsigned char crcval(0xFF);
  
  for ( int j = len; j; --j ) {
      crcval ^= *data++;

      for ( int i = 8; i; --i ) {
  crcval = ( crcval & 0x80 )
    ? (crcval << 1) ^ 0x31//polynomial value
    : (crcval << 1);
      }
  }
  return crcval; 
}


void SHT3x::writeCommand(unsigned short cmd) {
  Wire.beginTransmission(_i2caddr);
  Wire.write(cmd >> 8);
  Wire.write(cmd & 0xFF);
  Wire.endTransmission();      
}
