#ifndef _SHT3x_H_
#define _SHT3x_H_

#include "Arduino.h"
#include "Wire.h"

#define SHT3x_ADDR    0x45

class SHT3x {
  public:
    SHT3x();    
    bool begin(unsigned char i2caddr = SHT3x_ADDR);
    void startMeasure(void);
    bool getTempHumid(void);
    double humidity, temp;

  private:
    void writeCommand(unsigned short cmd);
    void reset(void);
    unsigned char crc8Dallas(const unsigned char *data, int len);
    unsigned char _i2caddr;
    
};

#endif
